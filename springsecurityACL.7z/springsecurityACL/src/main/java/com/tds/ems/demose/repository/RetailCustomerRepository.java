package com.tds.ems.demose.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.tds.ems.demose.entities.RetailCustomer;

public interface RetailCustomerRepository extends JpaRepository<RetailCustomer, Integer> {

}
