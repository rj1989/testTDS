package com.tds.ems.demose.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tds.ems.demose.entities.RetailCustomer;
import com.tds.ems.demose.repository.RetailCustomerRepository;

@Service
public class RetailCustomerService
{
	@Autowired
	RetailCustomerRepository retailCustomerRepository;
	
	public List<RetailCustomer> getAllReatailCustomers()   
    {  
		return retailCustomerRepository.findAll();
    } 

}
