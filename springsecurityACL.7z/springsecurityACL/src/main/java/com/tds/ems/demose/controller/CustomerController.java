package com.tds.ems.demose.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PostAuthorize;
import org.springframework.security.access.prepost.PostFilter;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.tds.ems.demose.entities.Customer;
import com.tds.ems.demose.service.CustomerService;


@RestController
public class CustomerController {
	
	@Autowired
    CustomerService customerService;

    @GetMapping("/customers")
    @PostFilter("hasPermission(filterObject, 'READ') or hasRole('CREATEUSER')")
    public List<Customer> getAllCustomers() {
    	return customerService.getAllCustomers();
    }
    
    @GetMapping("/customer/{id}")
    @PostAuthorize("hasPermission(returnObject, 'READ')")
    public Customer getCustomerById(@PathVariable("id") int id) {
        return customerService.getCustomerById(id);
    }
    
    @PutMapping("/customers")
    @PreAuthorize("hasPermission(#customer, 'WRITE')")
    public Customer updateCustomer(@RequestBody Customer customer) {
         return customerService.updateCustomer(customer);
        
    }
    
    @DeleteMapping("/customers")
    @PreAuthorize("hasPermission(#customer, 'DELETE')")
    public void deleteProduct(@RequestBody Customer customer) {
    	customerService.deleteProduct(customer);
        
    }
    
    @PostMapping("/customers")
    @PreAuthorize("hasRole('ROLE_ADMIN') or hasRole('CREATEUSER')")
    public Customer addProduct(@RequestBody Customer customer) {
    	return customerService.addCustomer(customer);
    }

}
