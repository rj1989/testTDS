package com.tds.ems.demose.entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class RetailCustomer extends Customer{
	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	String rid;
	String rdepartment;
	public String getRid() {
		return rid;
	}
	public void setRid(String rid) {
		this.rid = rid;
	}
	public String getRdepartment() {
		return rdepartment;
	}
	public void setRdepartment(String rdepartment) {
		this.rdepartment = rdepartment;
	}
	
	
	
}
