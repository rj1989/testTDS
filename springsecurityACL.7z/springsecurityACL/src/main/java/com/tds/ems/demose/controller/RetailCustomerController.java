package com.tds.ems.demose.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PostFilter;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.tds.ems.demose.entities.RetailCustomer;
import com.tds.ems.demose.service.RetailCustomerService;

@RestController
public class RetailCustomerController {

	@Autowired
    RetailCustomerService retailCustomerService;

    @GetMapping("/retailcustomers")
    @PostFilter("hasPermission(filterObject, 'READ')")
    public List<RetailCustomer> getAllRetailCustomerNames() {
    	return retailCustomerService.getAllReatailCustomers();
    }
}
