package com.tds.ems.demose;

import javax.sql.DataSource;

 

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.ehcache.EhCacheFactoryBean;
import org.springframework.cache.ehcache.EhCacheManagerFactoryBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.security.access.expression.method.DefaultMethodSecurityExpressionHandler;
import org.springframework.security.access.expression.method.MethodSecurityExpressionHandler;
import org.springframework.security.acls.AclPermissionEvaluator;
import org.springframework.security.acls.domain.AclAuthorizationStrategy;
import org.springframework.security.acls.domain.AclAuthorizationStrategyImpl;
import org.springframework.security.acls.domain.ConsoleAuditLogger;
import org.springframework.security.acls.domain.DefaultPermissionGrantingStrategy;
import org.springframework.security.acls.domain.EhCacheBasedAclCache;
import org.springframework.security.acls.jdbc.BasicLookupStrategy;
import org.springframework.security.acls.jdbc.JdbcMutableAclService;
import org.springframework.security.acls.jdbc.LookupStrategy;
import org.springframework.security.acls.model.AclService;
import org.springframework.security.acls.model.PermissionGrantingStrategy;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.method.configuration.GlobalMethodSecurityConfiguration;
import org.springframework.security.core.authority.SimpleGrantedAuthority;

@Configuration
@EnableGlobalMethodSecurity(prePostEnabled = true ,securedEnabled = true)
public class AclMethodSecurityConfiguration extends GlobalMethodSecurityConfiguration {

    @Autowired
    private MethodSecurityExpressionHandler defaultMethodSecurityExpressionHandler;

    @Override
    protected MethodSecurityExpressionHandler createExpressionHandler() {
    	System.out.println("inside MethodSecurityExpressionHandler");
        return defaultMethodSecurityExpressionHandler;
    }
    
    @Bean
    public MethodSecurityExpressionHandler defaultMethodSecurityExpressionHandler() {
    	System.out.println("inside defaultMethodSecurityExpressionHandler ");
        var expressionHandler = new DefaultMethodSecurityExpressionHandler();
        var permissionEvaluator = new AclPermissionEvaluator(aclService());
        expressionHandler.setPermissionEvaluator(permissionEvaluator);
        return expressionHandler;
    }
    
    @Bean
    public AclService aclService() {
    	System.out.println("inside AclService");
        return new JdbcMutableAclService(dataSource(), lookupStrategy(), aclCache());
    }

    @Bean
    public DataSource dataSource() {
    	System.out.println("inside DataSource");
        var ds = new DriverManagerDataSource();
        ds.setDriverClassName("org.postgresql.Driver");
        ds.setUrl("jdbc:postgresql://localhost:5432/test?currentSchema=public");
        ds.setUsername("postgres");
        ds.setPassword("postgres");
        return ds;
    }
    
    @Bean
    public LookupStrategy lookupStrategy() {
    	System.out.println("inside LookupStrategy ");
        return new BasicLookupStrategy(dataSource(), aclCache(), aclAuthorizationStrategy(), new ConsoleAuditLogger());
    }

    @Bean
    public EhCacheBasedAclCache aclCache() {
    	System.out.println("inside aclCache");
        return new EhCacheBasedAclCache(aclEhCacheFactoryBean().getObject(), permissionGrantingStrategy(),
                aclAuthorizationStrategy());
    }
    
    @Bean
    public EhCacheFactoryBean aclEhCacheFactoryBean() {
    	System.out.println("inside aclEhCacheFactoryBean ");
        EhCacheFactoryBean ehCacheFactoryBean = new EhCacheFactoryBean();
        ehCacheFactoryBean.setCacheManager(aclCacheManager().getObject());
        ehCacheFactoryBean.setCacheName("aclCache");
        return ehCacheFactoryBean;
    }
    
    @Bean
    public EhCacheManagerFactoryBean aclCacheManager() {
    	System.out.println("inside aclCacheManager ");
        return new EhCacheManagerFactoryBean();
    }
    
    @Bean
    public PermissionGrantingStrategy permissionGrantingStrategy() {
    	System.out.println("inside permissionGrantingStrategy");
        return new DefaultPermissionGrantingStrategy(new ConsoleAuditLogger());
    }
    
    @Bean
    public AclAuthorizationStrategy aclAuthorizationStrategy() {
    	System.out.println("inside aclAuthorizationStrategy");
        return new AclAuthorizationStrategyImpl((new SimpleGrantedAuthority("ROLE_ADMIN")));
    	

    }
    

    

  

   

    

  

    

    
}