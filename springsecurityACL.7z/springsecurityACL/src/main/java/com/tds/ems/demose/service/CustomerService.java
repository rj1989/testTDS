package com.tds.ems.demose.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tds.ems.demose.entities.Customer;
import com.tds.ems.demose.entities.Product;
import com.tds.ems.demose.repository.CustomerRepository;

@Service
public class CustomerService {
	
	@Autowired
	CustomerRepository customerRepository;
	
	public List<Customer> getAllCustomers()   
    {  
		return customerRepository.findAll();
    }  
      
    public Customer getCustomerById(int id)   
    {  
    	return customerRepository.findById(id);  
    }  
      
    public Customer updateCustomer(Customer customer)   
    {  
        return customerRepository.save(customer);  
    }
    
    public void deleteProduct(Customer customer)
    {
    	customerRepository.delete(customer);
 
    }
    public Customer addCustomer(Customer customer)   
    {  
        return customerRepository.save(customer);  
    }
  

}
