package com.tds.ems.demose.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.tds.ems.demose.entities.Customer;



public interface CustomerRepository extends JpaRepository<Customer, Integer>{
	public Customer findById(int id);
	
}
